from tkinter import *
import datetime,time

class IDC:
    def __init__(self):
        self.tk=Tk()
        self.tk.title('身份证信息校验')
        self.tk.geometry('790x540')
        self.tk['bg'] = 'lightblue'
        #图片
        self.image = PhotoImage(file='C:\\python上课练习.py\\身份证.png')
        self.Label_image = Label(self.tk,image =self.image)
        self.Label_image.place(x=10,y=10)
        #校验
        self.label1 = Label(self.tk,text='请输入身份证号码：',font=('微软雅黑',12,'bold'),bg='navy',fg='lightblue')
        self.label1.place(x=370,y=10)
        #校验框
        self.entry = Entry(self.tk,font=('微软雅黑',15,'bold'),width=25,fg='lightblue')
        self.entry.place(x=369,y=45)
        #校验按钮
        self.button = Button(self.tk, text='校验',font=('微软雅黑', 11, 'bold'), width=6, fg='navy',command=self.jiaoyan)
        self.button.place(x=700,y=45)
        #是否有效
        self.label2 = Label(self.tk, text='是否有效：', font=('微软雅黑', 13, 'bold'), fg='navy', bg='lightblue')
        self.label2.place(x=370, y=140)
        #是否有效框
        self.result = StringVar()
        self.entry1 = Entry(self.tk, font=('微软雅黑', 15, 'bold'), width=9, fg='lightblue',state=DISABLED,textvariable=self.result)
        self.entry1.place(x=460, y=140)
        #性别
        self.label3 = Label(self.tk, text='性别：', font=('微软雅黑', 13, 'bold'), fg='navy', bg='lightblue')
        self.label3.place(x=402, y=200)
        # 性别框
        self.result1 = StringVar()
        self.entry1 = Entry(self.tk, font=('微软雅黑', 15, 'bold'), width=9, fg='lightblue',state=DISABLED,textvariable=self.result1)
        self.entry1.place(x=460, y=200)
        #出生日期
        self.label4 = Label(self.tk, text='出生日期：', font=('微软雅黑', 13, 'bold'), fg='navy', bg='lightblue')
        self.label4.place(x=370, y=260)
        #出生日期框
        self.result2=StringVar()
        self.entry3 = Entry(self.tk, font=('微软雅黑', 15, 'bold'), width=18, fg='lightblue',state=DISABLED,textvariable=self.result2)
        self.entry3.place(x=460, y=260)
        #所在地
        self.label4 = Label(self.tk, text='所在地：', font=('微软雅黑', 13, 'bold'), fg='navy', bg='lightblue')
        self.label4.place(x=385, y=320)
        # 所在地框
        self.result3 = StringVar()
        self.entry4 = Entry(self.tk, font=('微软雅黑', 15, 'bold'), width=18, fg='lightblue', state=DISABLED,textvariable=self.result3)
        self.entry4.place(x=460, y=320)
        self.result3.set("")
        # 关闭
        self.button1 = Button(self.tk, text='关闭',font=('微软雅黑', 12, 'bold'), width=8, fg='navy',command=self.guanbi)
        self.button1.place(x=620,y=450)
        self.qidong()
    def qidong(self):
        self.tk.mainloop()
    def guanbi(self):
        self.tk.destroy()
    def xb(self):
        huoquxb = self.entry.get()
        ea=huoquxb[16]
        if int(ea) % 2 == 0:
            self.result1.set("女")
        else:
            self.result1.set("男")
    def riqi(self):
        inputriqi=self.entry.get()
        # 获取1970-1-2时间戳
        odate = datetime.datetime(1970, 1, 2)
        otime = time.mktime(odate.timetuple())
        # 现在的时间戳
        now = time.time()
        # 身份证日期的时间戳
        # print(inputriqi)
        year = inputriqi[6:10]
        month = inputriqi[10:12]
        day = inputriqi[12:14]
        ymd = datetime.datetime(int(year), int(month), int(day))
        yearmd = time.mktime(ymd.timetuple())
        # 判断
        if otime < yearmd and yearmd < now:
            self.result2.set("%s-%s-%s"%(year,month,day))
        else:
            return False
    def dizhi(self):
        # 获取到所有的归属地
        inputdizhi = self.entry.get()
        f = open(file="diqu.txt", mode='r', encoding="utf-8")
        qbdz = f.readlines()
        res_area = ''
        for item in qbdz:
            if inputdizhi[:6] == item[:6]:
                res_area = item[6:]
                # print(res_area)
        if res_area == '':
            self.result3.set("")
        else:
            self.result3.set(res_area)


    def hefa(self):
        inputhefa = self.entry.get()
        self.exits=inputhefa[0:17]
        # 系数
        si_list = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        yanzhengma = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
        # 验证
        num= 0
        for i in range(len(self.exits)):
            num += int(inputhefa[i]) * int(si_list[i])
        yushu = num % 11
        if inputhefa[17:] == yanzhengma[yushu]:
            self.result.set('有效')
        else:
            self.result.set('无效')
            if inputhefa[17:] != yanzhengma[yushu]:
                self.result1.set('')
                self.result2.set('')
                self.result3.set('')
    # 校验按钮事件
    def jiaoyan(self):
        self.riqi()
        self.dizhi()
        self.xb()
        self.hefa()



IDC()





























